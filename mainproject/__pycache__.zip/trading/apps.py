from django.apps import AppConfig


class TradingConfig(AppConfig):
    name = 'trading'
